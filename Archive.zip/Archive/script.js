/* styles.css */
body {
  margin: 0;
  font-family: 'Courier New', Courier, monospace;
  background-color: black;
  color: white;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.terminal {
  text-align: center;
  max-width: 600px;
  width: 90%;
  border: 2px solid green;
  padding: 20px;
  border-radius: 10px;
  background: #111;
  box-shadow: 0 0 20px green;
}

h1 {
  color: green;
  margin-bottom: 20px;
}

.status {
  display: flex;
  justify-content: space-between;
  font-size: 18px;
  margin-bottom: 20px;
}

.output {
  background: #222;
  padding: 15px;
  border-radius: 5px;
  min-height: 80px;
  margin-bottom: 15px;
}

#command-input {
  width: 80%;
  padding: 10px;
  font-size: 16px;
  color: white;
  background: black;
  border: 1px solid green;
  border-radius: 5px;
}

button {
  padding: 10px 20px;
  font-size: 16px;
  color: black;
  background: green;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background: lime;
}